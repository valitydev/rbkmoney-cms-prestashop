<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{rbkmoney_payment}prestashop>rbkmoney_payment_5ab0cb91c20790b9ceb4587014bb94c3'] = 'Платежная система RBKmoney';
$_MODULE['<{rbkmoney_payment}prestashop>rbkmoney_payment_54c12e4a41650a8ee6a994f6a116348b'] = 'Прием платежей через платежную систему RBKmoney';
$_MODULE['<{rbkmoney_payment}prestashop>rbkmoney_payment_c9493419e405fe3f744495ae9e11d5f1'] = 'Вы действительно хотите удалить?';
$_MODULE['<{rbkmoney_payment}prestashop>rbkmoney_payment_84998325451483386d5501d712f828d4'] = 'Подтверждение';
$_MODULE['<{rbkmoney_payment}prestashop>rbkmoney_payment_f45d1ccef95c393b9488535a28ee5e3c'] = 'Настройки обновлены';
$_MODULE['<{rbkmoney_payment}prestashop>rbkmoney_payment_e537a4522c35016b826545f3ea488f7f'] = 'Настройки платежного модуля RBKmoney';
$_MODULE['<{rbkmoney_payment}prestashop>rbkmoney_payment_b45419fdb865ff3a8a4b01a22307998a'] = 'Обязательные настройки';
$_MODULE['<{rbkmoney_payment}prestashop>rbkmoney_payment_24f6d0a5e981497218465d35e9702dae'] = 'ID магазина';
$_MODULE['<{rbkmoney_payment}prestashop>rbkmoney_payment_d88944933da63e116ea02de42748543f'] = 'Ваш ключ для доступа к API из';
$_MODULE['<{rbkmoney_payment}prestashop>rbkmoney_payment_3231caef526f2897016a45d6a8356d78'] = 'Ключ подписи получаемых на Webhook уведомлений из';
$_MODULE['<{rbkmoney_payment}prestashop>rbkmoney_payment_8836dc60baab3ea9a8494879f7083a61'] = 'Кастомизация формы оплаты';
$_MODULE['<{rbkmoney_payment}prestashop>rbkmoney_payment_de744f6c62885fd8a8ef7de61b3f48e1'] = 'URL логотипа';
$_MODULE['<{rbkmoney_payment}prestashop>rbkmoney_payment_2d8f701fed0dde2107f7bfb14541ee16'] = 'Текст кнопки открытия формы оплаты';
$_MODULE['<{rbkmoney_payment}prestashop>rbkmoney_payment_38ca0af80cd7bd241500e81ba2e6efff'] = 'Описание';
$_MODULE['<{rbkmoney_payment}prestashop>rbkmoney_payment_2d4a359881e3b8628cc10e305f999027'] = 'Название магазина';
$_MODULE['<{rbkmoney_payment}prestashop>rbkmoney_payment_7b6dcfd94bd91efb019395d97d769317'] = 'Дополнительные настройки';
$_MODULE['<{rbkmoney_payment}prestashop>rbkmoney_payment_5d45573134bc02fe77b537023be1680b'] = 'Сохранять лог RBKmoney API (Расширенные параметры > Журнал событий)';
$_MODULE['<{rbkmoney_payment}prestashop>rbkmoney_payment_3d300329be2a963d8f95b23c95c406c9'] = 'Документация';
$_MODULE['<{rbkmoney_payment}prestashop>rbkmoney_payment_2ac43e46df7749ea0c4bf994c170ff35'] = 'Документация по интеграции';
$_MODULE['<{rbkmoney_payment}prestashop>rbkmoney_payment_a5495e6f3a128fa2980a9e5df835ba62'] = 'Документация для работы с вебхуками';
$_MODULE['<{rbkmoney_payment}prestashop>rbkmoney_payment_4965fac0434277e3810d837264baf801'] = 'Документация по кастомизации платежной формы';
$_MODULE['<{rbkmoney_payment}prestashop>rbkmoney_payment_0f1f08d30a69afd8d9961d29dd264a9f'] = 'Обновить настройки';
$_MODULE['<{rbkmoney_payment}prestashop>payment_infos_348378baa656d63bc1dd15d176aba228'] = 'RBKmoney — это современный, простой и удобный платежный сервис для вашего бизнеса. Нашим партнерам мы предлагаем самые популярные методы платежей, в том числе с помощью банковских карт VISA и MasterCard, банковских и денежных переводов, интернет-банкинга, электронных денег, а также широкой сети терминалов и салонов связи.';
$_MODULE['<{rbkmoney_payment}prestashop>payment_success_e0552a467b9073d45ed2b2079f9c27b2'] = 'Вы совершили успешный платеж';
$_MODULE['<{rbkmoney_payment}prestashop>payment_success_5efd8f2a27aecc6951c39eb9f9dfaeb2'] = 'Ожидайте обработки заказа';
