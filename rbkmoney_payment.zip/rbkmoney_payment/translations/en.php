<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{rbkmoney_payment}prestashop>rbkmoney_payment_5ab0cb91c20790b9ceb4587014bb94c3'] = 'Payment system RBKmoney';
$_MODULE['<{rbkmoney_payment}prestashop>rbkmoney_payment_54c12e4a41650a8ee6a994f6a116348b'] = 'Accept payments by RBKmoney payment system';
$_MODULE['<{rbkmoney_payment}prestashop>rbkmoney_payment_c9493419e405fe3f744495ae9e11d5f1'] = 'Do you want to remove?';
$_MODULE['<{rbkmoney_payment}prestashop>rbkmoney_payment_84998325451483386d5501d712f828d4'] = 'Confirmation';
$_MODULE['<{rbkmoney_payment}prestashop>rbkmoney_payment_f45d1ccef95c393b9488535a28ee5e3c'] = 'Settings updated';
$_MODULE['<{rbkmoney_payment}prestashop>rbkmoney_payment_e537a4522c35016b826545f3ea488f7f'] = 'Configuration of the payment module RBKmoney';
$_MODULE['<{rbkmoney_payment}prestashop>rbkmoney_payment_b45419fdb865ff3a8a4b01a22307998a'] = 'Mandatory settings';
$_MODULE['<{rbkmoney_payment}prestashop>rbkmoney_payment_24f6d0a5e981497218465d35e9702dae'] = 'Shop ID';
$_MODULE['<{rbkmoney_payment}prestashop>rbkmoney_payment_d88944933da63e116ea02de42748543f'] = 'Your key to access API from';
$_MODULE['<{rbkmoney_payment}prestashop>rbkmoney_payment_3231caef526f2897016a45d6a8356d78'] = 'Key signatures received on the Webhook notification from';
$_MODULE['<{rbkmoney_payment}prestashop>rbkmoney_payment_8836dc60baab3ea9a8494879f7083a61'] = 'Customization of forms of payment';
$_MODULE['<{rbkmoney_payment}prestashop>rbkmoney_payment_de744f6c62885fd8a8ef7de61b3f48e1'] = 'URL logo';
$_MODULE['<{rbkmoney_payment}prestashop>rbkmoney_payment_2d8f701fed0dde2107f7bfb14541ee16'] = 'The text of the button open a form of payment';
$_MODULE['<{rbkmoney_payment}prestashop>rbkmoney_payment_38ca0af80cd7bd241500e81ba2e6efff'] = 'Description';
$_MODULE['<{rbkmoney_payment}prestashop>rbkmoney_payment_2d4a359881e3b8628cc10e305f999027'] = 'Store name';
$_MODULE['<{rbkmoney_payment}prestashop>rbkmoney_payment_7b6dcfd94bd91efb019395d97d769317'] = 'Additional settings';
$_MODULE['<{rbkmoney_payment}prestashop>rbkmoney_payment_5d45573134bc02fe77b537023be1680b'] = 'To save the log RBKmoney API (Advanced options > event Log)';
$_MODULE['<{rbkmoney_payment}prestashop>rbkmoney_payment_3d300329be2a963d8f95b23c95c406c9'] = 'Documentation';
$_MODULE['<{rbkmoney_payment}prestashop>rbkmoney_payment_2ac43e46df7749ea0c4bf994c170ff35'] = 'Integration documentation';
$_MODULE['<{rbkmoney_payment}prestashop>rbkmoney_payment_a5495e6f3a128fa2980a9e5df835ba62'] = 'Documentation for working with webhooks';
$_MODULE['<{rbkmoney_payment}prestashop>rbkmoney_payment_4965fac0434277e3810d837264baf801'] = 'Documentation for the customization of the payment form';
$_MODULE['<{rbkmoney_payment}prestashop>rbkmoney_payment_0f1f08d30a69afd8d9961d29dd264a9f'] = 'To update the settings';
$_MODULE['<{rbkmoney_payment}prestashop>payment_infos_348378baa656d63bc1dd15d176aba228'] = 'RBKmoney is a modern, simple and convenient payment service for your business. To our partners we offer the most popular payment methods, including Bank cards VISA and MasterCard, Bank and money transfer, Internet banking, electronic money, and a wide network of terminals and shops.';
$_MODULE['<{rbkmoney_payment}prestashop>payment_success_e0552a467b9073d45ed2b2079f9c27b2'] = 'You made a successful payment';
$_MODULE['<{rbkmoney_payment}prestashop>payment_success_5efd8f2a27aecc6951c39eb9f9dfaeb2'] = 'Expect order processing';
